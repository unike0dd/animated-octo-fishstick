# Gabriel Professional Services

A high-fidelity corporate website for Gabriel Professional Services, featuring a React frontend with interactive 3D elements (Three.js/Fiber) and a Dart backend API.

## Project Structure

- **Frontend**: React, Tailwind CSS, Framer Motion, React Three Fiber.
- **Backend**: Dart, Shelf.

## Getting Started

### Prerequisites

- Node.js (for serving the frontend)
- Dart SDK (for running the backend)

### Running the Frontend

The frontend uses ES Modules and CDNs, so it requires a static file server to run correctly (opening `index.html` directly in the browser will not work due to CORS policies on modules).

```bash
# Install the 'serve' utility (one-time setup)
npm install

# Start the frontend
npm start
```

Visit `http://localhost:3000` in your browser.

### Running the Backend

The backend is a Dart application located in the `backend/` directory.

```bash
# Navigate to backend directory
cd backend

# Get dependencies
dart pub get

# Run the server
dart run bin/server.dart
```

The backend server will start on port 8080.

## Features

- **3D Elements**: Interactive starfield hero section and 3D logo.
- **Animations**: Smooth page transitions and scroll animations using Framer Motion.
- **Responsive Design**: Fully responsive layout optimized for mobile and desktop.
- **Dark Mode**: System-aware dark mode support.
