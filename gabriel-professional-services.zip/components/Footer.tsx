import React from 'react';
import { Rocket, Mail, Phone, MapPin } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface FooterProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, language }) => {
  const t = translations[language].footer;

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-gradient-to-br from-brand-600 to-brand-400 rounded-lg flex items-center justify-center text-white">
                 <Rocket size={22} />
               </div>
               <div className="flex flex-col">
                 <span className="text-xl font-bold tracking-tight leading-none text-white">Gabriel</span>
                 <span className="text-[10px] font-medium text-gray-400 uppercase tracking-widest mt-0.5">Outsource Delivered</span>
               </div>
            </div>
            <p className="text-gray-400 leading-relaxed text-sm">
              {t.description}
            </p>
            <div className="text-sm text-gray-500">
                &copy; 2026 Gabriel. {t.rights}
            </div>
          </div>

          {/* Services Column */}
          <div>
            <h3 className="text-lg font-semibold mb-6">{t.services}</h3>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('services', 'logistics-section')}>{t.links.logistics}</li>
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('services', 'it-support-section')}>{t.links.itsupport}</li>
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('services', 'admin-section')}>{t.links.admin}</li>
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('services', 'relations-section')}>{t.links.relations}</li>
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h3 className="text-lg font-semibold mb-6">{t.company}</h3>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('about')}>{t.links.about}</li>
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('careers')}>{t.links.careers}</li>
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('learning')}>{t.links.learning}</li>
              <li className="hover:text-brand-400 cursor-pointer transition-colors" onClick={() => onNavigate('contact')}>{t.links.contact}</li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-lg font-semibold mb-6">{t.contact}</h3>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li className="flex items-start gap-3">
                <Mail size={18} className="mt-0.5 text-brand-500" />
                <span>hello@gabriel.services</span>
              </li>
              <li className="flex items-start gap-3">
                <Phone size={18} className="mt-0.5 text-brand-500" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={18} className="mt-0.5 text-brand-500" />
                <span>San Francisco, CA</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
            <div className="flex flex-wrap gap-6 mb-4 md:mb-0">
                <button onClick={() => onNavigate('privacy')} className="hover:text-white transition-colors">{t.privacy}</button>
                <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">{t.terms}</button>
                <button onClick={() => onNavigate('gdpr')} className="hover:text-white transition-colors">{t.gdpr}</button>
                <button onClick={() => onNavigate('consent')} className="hover:text-white transition-colors">{t.consent}</button>
            </div>
            <div>
                {t.tagline}
            </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;