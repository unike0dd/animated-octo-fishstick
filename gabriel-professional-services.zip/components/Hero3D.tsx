import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Stars, Float, MeshDistortMaterial, Sphere } from '@react-three/drei';
import * as THREE from 'three';

const NeuralMesh = () => {
  const meshRef = useRef<THREE.Group>(null);
  const { mouse } = useThree();

  const points = useMemo(() => {
    const p = [];
    for (let i = 0; i < 50; i++) {
      p.push(new THREE.Vector3(
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10
      ));
    }
    return p;
  }, []);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.001;
      meshRef.current.rotation.x += 0.0005;
      meshRef.current.position.x = THREE.MathUtils.lerp(meshRef.current.position.x, mouse.x * 0.3, 0.05);
      meshRef.current.position.y = THREE.MathUtils.lerp(meshRef.current.position.y, mouse.y * 0.3, 0.05);
    }
  });

  return (
    <group ref={meshRef}>
      <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.5}>
        <Sphere args={[1.5, 64, 64]}>
          <MeshDistortMaterial
            color="#7c3aed"
            attach="material"
            distort={0.3}
            speed={1.5}
            roughness={0.1}
            metalness={0.8}
            transparent
            opacity={0.4}
          />
        </Sphere>
      </Float>
      
      {points.map((pos, i) => (
        <mesh key={i} position={pos}>
          <sphereGeometry args={[0.015, 8, 8]} />
          <meshBasicMaterial color="#a78bfa" transparent opacity={0.2} />
        </mesh>
      ))}
    </group>
  );
};

const StarField = () => {
  const starRef = useRef<any>(null);
  
  useFrame((state) => {
    if (starRef.current) {
      const t = state.clock.getElapsedTime();
      
      // Gentle rotation for dynamic background
      starRef.current.rotation.y = t * 0.02;
      starRef.current.rotation.x = Math.sin(t * 0.1) * 0.05;
      
      // Twinkle: Oscillate scale slightly to simulate light variance
      const s = 1 + Math.sin(t * 3) * 0.005;
      starRef.current.scale.set(s, s, s);
      
      // Immersive slow zoom
      state.camera.position.z = THREE.MathUtils.lerp(state.camera.position.z, 3, 0.0005);
    }
  });

  return (
    <group ref={starRef}>
      <Stars 
        radius={100} 
        depth={60} 
        count={6000} 
        factor={6} 
        saturation={0} 
        fade 
        speed={1} 
      />
    </group>
  );
}

const Hero3D: React.FC = () => {
  return (
    <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
      <Canvas 
        camera={{ position: [0, 0, 10], fov: 75 }} 
        gl={{ alpha: true, antialias: true, powerPreference: "high-performance" }}
      >
        <ambientLight intensity={0.4} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#8b5cf6" />
        <pointLight position={[-10, -10, -10]} intensity={0.3} color="#3b82f6" />
        
        <NeuralMesh />
        <StarField />
      </Canvas>
      
      <div className="absolute inset-0 bg-gradient-to-b from-white/10 via-white/40 to-white dark:from-gray-900/30 dark:via-gray-900/60 dark:to-gray-900 transition-all duration-700"></div>
    </div>
  );
};

export default Hero3D;