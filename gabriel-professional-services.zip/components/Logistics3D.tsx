
import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sphere, Float, MeshDistortMaterial, Line } from '@react-three/drei';
import * as THREE from 'three';

const DataArc = ({ start, end, color }: { start: [number, number, number], end: [number, number, number], color: string }) => {
  const curve = useMemo(() => {
    const startVec = new THREE.Vector3(...start);
    const endVec = new THREE.Vector3(...end);
    const midVec = startVec.clone().lerp(endVec, 0.5).normalize().multiplyScalar(4);
    return new THREE.QuadraticBezierCurve3(startVec, midVec, endVec);
  }, [start, end]);

  const points = curve.getPoints(50);

  return (
    <Line
      points={points}
      color={color}
      lineWidth={1}
      transparent
      opacity={0.3}
    />
  );
};

const LogisticsGlobe = () => {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.002;
    }
  });

  const arcs = useMemo(() => {
    const a = [];
    for (let i = 0; i < 15; i++) {
      const start: [number, number, number] = [
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 6
      ];
      const end: [number, number, number] = [
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 6
      ];
      a.push({ start, end, color: i % 2 === 0 ? '#7c3aed' : '#3b82f6' });
    }
    return a;
  }, []);

  return (
    <group ref={groupRef}>
      <Sphere args={[3, 64, 64]}>
        <meshStandardMaterial color="#111827" wireframe />
      </Sphere>
      <Sphere args={[2.9, 64, 64]}>
        <MeshDistortMaterial
          color="#1e1b4b"
          distort={0.2}
          speed={2}
          roughness={0.4}
        />
      </Sphere>
      {arcs.map((arc, i) => (
        <DataArc key={i} {...arc} />
      ))}
    </group>
  );
};

const Logistics3D: React.FC = () => {
  return (
    <div className="w-full h-[400px] md:h-[600px] relative bg-gray-900 rounded-[3rem] overflow-hidden shadow-2xl border border-gray-800">
      <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1.5} />
        <LogisticsGlobe />
      </Canvas>
      <div className="absolute bottom-8 left-8 bg-black/50 backdrop-blur-md p-4 rounded-2xl border border-white/10">
        <div className="flex items-center gap-2 text-brand-400 font-bold text-xs uppercase tracking-widest mb-1">
          <div className="w-2 h-2 rounded-full bg-brand-400 animate-ping"></div>
          Live Logistics Network
        </div>
        <div className="text-white text-lg font-bold">1,248 Active Nodes</div>
      </div>
    </div>
  );
};

export default Logistics3D;
