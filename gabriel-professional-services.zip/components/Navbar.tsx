import React, { useState } from 'react';
import { Menu, X, ChevronDown, Moon, Sun, Languages, Smartphone } from 'lucide-react';
import { Page, Language } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import RocketLogo from './RocketLogo';
import { translations } from '../translations';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page, sectionId?: string) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  language: Language;
  toggleLanguage: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate, isDarkMode, toggleTheme, language, toggleLanguage }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isServicesHovered, setIsServicesHovered] = useState(false);

  const t = translations[language].nav;

  const navLinks: { label: string; value: any; hasDropdown?: boolean; icon?: React.ReactNode }[] = [
    { label: t.home, value: 'home' },
    { label: t.services, value: 'services', hasDropdown: true },
    { label: language === 'EN' ? 'Mobile' : 'Móvil', value: 'mobile-preview', icon: <Smartphone size={14} /> },
    { label: t.about, value: 'about' },
    { label: t.contact, value: 'contact' },
  ];

  const servicesSubmenu = [
    { label: t.submenu.logistics, section: 'logistics-section' },
    { label: t.submenu.itsupport, section: 'it-support-section' },
    { label: t.submenu.admin, section: 'admin-section' },
    { label: t.submenu.relations, section: 'relations-section' }
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div 
            className="flex-shrink-0 flex items-center cursor-pointer gap-2 group"
            onClick={() => onNavigate('home')}
          >
            <div className="flex items-center justify-center -ml-2">
              <RocketLogo />
            </div>
            
            <div className="flex flex-col justify-center">
              <span className="text-xl font-bold text-gray-900 dark:text-white tracking-tight leading-none group-hover:text-brand-700 dark:group-hover:text-brand-400 transition-colors duration-300">Gabriel</span>
              <span className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-widest group-hover:text-brand-500 dark:group-hover:text-brand-300 transition-colors duration-300 mt-0.5">Outsource Delivered</span>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-2">
            {navLinks.map((link) => (
              <div 
                key={link.value}
                className="relative group h-20 flex items-center px-1"
                onMouseEnter={() => link.hasDropdown && setIsServicesHovered(true)}
                onMouseLeave={() => link.hasDropdown && setIsServicesHovered(false)}
              >
                <button
                  onClick={() => onNavigate(link.value)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 flex items-center gap-1.5
                    ${currentPage === link.value 
                      ? 'text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-900/20' 
                      : 'text-gray-600 dark:text-gray-300 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-brand-50/50 dark:hover:bg-brand-900/10'}
                  `}
                >
                  {link.icon}
                  {link.label}
                  {link.hasDropdown && <ChevronDown size={14} className={`transition-transform duration-200 ${isServicesHovered && link.hasDropdown ? 'rotate-180' : ''}`} />}
                </button>
                
                {currentPage === link.value && (
                  <motion.div 
                    layoutId="navbar-indicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-600 dark:bg-brand-400 mx-4"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}

                {link.hasDropdown && (
                  <AnimatePresence>
                    {isServicesHovered && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-16 left-0 w-64 bg-white dark:bg-gray-800 shadow-xl rounded-xl border border-gray-100 dark:border-gray-700 py-2 overflow-hidden z-50 ring-1 ring-black ring-opacity-5"
                      >
                        {servicesSubmenu.map((item, idx) => (
                          <div 
                            key={idx}
                            className="px-4 py-3 text-sm text-gray-600 dark:text-gray-300 hover:bg-brand-50 dark:hover:bg-brand-900/30 hover:text-brand-700 dark:hover:text-brand-300 cursor-pointer transition-colors duration-150 flex items-center gap-2 group/item"
                            onClick={(e) => {
                              e.stopPropagation();
                              onNavigate('services', item.section);
                              setIsServicesHovered(false);
                            }}
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-300 dark:bg-brand-600 opacity-0 group-hover/item:opacity-100 transition-opacity"></span>
                            {item.label}
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                )}
              </div>
            ))}
          </div>

          <div className="hidden md:flex items-center space-x-3">
             <button 
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-bold text-gray-600 dark:text-gray-300 hover:bg-brand-50 dark:hover:bg-brand-900/20 hover:text-brand-600 dark:hover:text-brand-400 transition-all border border-transparent hover:border-brand-100 dark:hover:border-brand-800"
              aria-label="Toggle Language"
            >
              <Languages size={18} />
              <span>{language}</span>
            </button>
             <button 
              onClick={toggleTheme}
              className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-brand-50/50 dark:hover:bg-brand-900/10 hover:text-brand-600 dark:hover:text-brand-400 transition-colors"
              aria-label="Toggle Dark Mode"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button 
              onClick={() => onNavigate('signin')}
              className="px-4 py-2 rounded-full text-gray-600 dark:text-gray-300 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-brand-50/50 dark:hover:bg-brand-900/10 font-medium text-sm transition-all duration-200"
            >
              {t.signin}
            </button>
            <button 
              onClick={() => onNavigate('getstarted')}
              className="bg-brand-600 hover:bg-brand-700 dark:bg-brand-600 dark:hover:bg-brand-500 text-white px-6 py-2.5 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-brand-500/30 transform hover:-translate-y-0.5 active:scale-95 active:translate-y-0"
            >
              {t.getstarted}
            </button>
          </div>

          <div className="md:hidden flex items-center gap-2">
            <button 
                onClick={toggleLanguage}
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-sm font-bold text-gray-600 dark:text-gray-300"
              >
                <Languages size={18} />
                <span>{language}</span>
            </button>
            <button 
                onClick={toggleTheme}
                className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-brand-50/50 dark:hover:bg-brand-900/10 hover:text-brand-600 dark:hover:text-brand-400 transition-colors"
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-brand-50/50 dark:hover:bg-brand-900/10 focus:outline-none transition-colors duration-200"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {navLinks.map((link) => (
                <div key={link.value}>
                  <button
                    onClick={() => {
                      onNavigate(link.value);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`block w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-colors
                      ${currentPage === link.value 
                        ? 'bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400' 
                        : 'text-gray-600 dark:text-gray-300 hover:bg-brand-50/50 dark:hover:bg-brand-900/10 hover:text-brand-600 dark:hover:text-brand-400'}
                    `}
                  >
                    <div className="flex items-center gap-2">
                      {link.icon}
                      {link.label}
                    </div>
                  </button>
                  {link.hasDropdown && (
                    <div className="pl-6 space-y-1 mt-1 border-l-2 border-gray-100 dark:border-gray-800 ml-4">
                      {servicesSubmenu.map((sub, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                             onNavigate('services', sub.section);
                             setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left px-4 py-2.5 text-sm text-gray-500 dark:text-gray-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-brand-50/50 dark:hover:bg-brand-900/10 rounded-lg transition-colors"
                        >
                          {sub.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div className="pt-4 flex flex-col space-y-3 px-2">
                <button 
                  onClick={() => {
                    onNavigate('signin');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full text-center text-gray-600 dark:text-gray-300 font-medium py-3 rounded-xl hover:bg-brand-50/50 dark:hover:bg-brand-900/10 hover:text-brand-600 dark:hover:text-brand-400 transition-colors"
                >
                  {t.signin}
                </button>
                <button 
                  onClick={() => {
                    onNavigate('getstarted');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full bg-brand-600 text-white px-4 py-3 rounded-xl font-medium shadow-md hover:bg-brand-700 active:scale-95 transition-all"
                >
                  {t.getstarted}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
