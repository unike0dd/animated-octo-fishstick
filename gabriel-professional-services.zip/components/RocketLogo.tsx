
import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// Removed manual JSX augmentations that were causing global conflicts with standard HTML elements.
// React Three Fiber elements are typically handled by the library's own type definitions.

const RocketModel = ({ hovered }: { hovered: boolean }) => {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.5;
      
      if (hovered) {
        groupRef.current.rotation.y += delta * 2;
        groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, -0.2, delta * 5);
      } else {
        groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, 0, delta * 5);
      }
    }
  });

  return (
    <group ref={groupRef} rotation={[0.2, 0, 0]} scale={0.8}>
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.35, 0.45, 1.4, 32]} />
        <meshStandardMaterial color="#ffffff" metalness={0.3} roughness={0.4} />
      </mesh>
      
      <mesh position={[0, 0.95, 0]}>
        <coneGeometry args={[0.35, 0.5, 32]} />
        <meshStandardMaterial color="#7c3aed" metalness={0.5} roughness={0.2} />
      </mesh>

      <mesh position={[0, 0.3, 0.38]} rotation={[0.2, 0, 0]}>
        <sphereGeometry args={[0.15, 32, 32]} />
        <meshStandardMaterial color="#3b82f6" metalness={0.8} roughness={0.1} />
      </mesh>

      {[0, 1, 2, 3].map((i) => (
        <mesh 
          key={i} 
          position={[
            Math.sin(i * Math.PI * 0.5) * 0.45, 
            -0.6, 
            Math.cos(i * Math.PI * 0.5) * 0.45
          ]}
          rotation={[0, -i * Math.PI * 0.5, 0]}
        >
          <boxGeometry args={[0.1, 0.4, 0.4]} />
          <meshStandardMaterial color="#7c3aed" metalness={0.5} roughness={0.2} />
        </mesh>
      ))}

      <mesh position={[0, -0.8, 0]}>
        <cylinderGeometry args={[0.25, 0.1, 0.2, 32]} />
        <meshBasicMaterial color="#f59e0b" />
      </mesh>
    </group>
  );
};

const RocketLogo: React.FC = () => {
  const [hovered, setHovered] = useState(false);

  return (
    <div 
      className="w-12 h-12 relative"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <Canvas 
        camera={{ position: [0, 0, 3], fov: 45 }}
        gl={{ alpha: true, antialias: true }}
      >
        <ambientLight intensity={0.8} />
        <pointLight position={[10, 10, 10]} intensity={1.5} />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#7c3aed" />
        <RocketModel hovered={hovered} />
      </Canvas>
    </div>
  );
};

export default RocketLogo;
