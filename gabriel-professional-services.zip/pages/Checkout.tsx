import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, CreditCard, Lock, CheckCircle, ArrowLeft, Loader2, Info, Home } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface CheckoutProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  language: Language;
  initialPlan?: string;
  onSetPlan?: (planId: string) => void;
}

type PlanKey = 'logistics' | 'itsupport_l1' | 'itsupport_l2' | 'admin' | 'relations';

const Checkout: React.FC<CheckoutProps> = ({ onNavigate, language, initialPlan, onSetPlan }) => {
  const t = (translations[language] || translations['EN']).checkout;
  const isEn = language === 'EN';

  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [selectedService, setSelectedService] = useState<PlanKey>((initialPlan as PlanKey) || 'itsupport_l1');

  // Synchronize state if prop changes (though usually navigates with it)
  useEffect(() => {
    if (initialPlan) {
      setSelectedService(initialPlan as PlanKey);
    }
  }, [initialPlan]);

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    // Simulate secure processing delay
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2500);
  };

  const currentPrice = t.prices[selectedService];

  if (isSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-white dark:bg-gray-800 rounded-3xl p-10 text-center shadow-2xl border border-green-100 dark:border-green-900/30"
        >
          <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle size={48} />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t.success}</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-10 leading-relaxed">
            {t.successDesc}
          </p>
          <button 
            onClick={() => onNavigate('home')}
            className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-4 rounded-2xl transition-all shadow-xl shadow-brand-500/20"
          >
            {isEn ? 'Return to Dashboard' : 'Volver al Panel'}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <button 
            onClick={() => onNavigate('services')}
            className="flex items-center gap-2 text-gray-500 dark:text-gray-400 hover:text-brand-600 transition-colors group"
          >
            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
            {isEn ? 'Back to Services' : 'Volver a Servicios'}
          </button>
          
          <button 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all shadow-sm group"
          >
            <Home size={18} className="group-hover:text-brand-600 transition-colors" />
            <span className="font-bold text-sm">{isEn ? 'Home' : 'Inicio'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left: Form */}
          <div className="lg:col-span-7 space-y-8">
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 md:p-10 shadow-sm border border-gray-100 dark:border-gray-700">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{t.title}</h1>
              <p className="text-gray-500 dark:text-gray-400 mb-10">{t.subtitle}</p>

              <form onSubmit={handlePayment} className="space-y-8">
                {/* Billing Info Section */}
                <div>
                  <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <Info size={16} /> {t.billingInfo}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input required type="text" placeholder={isEn ? "Full Name" : "Nombre Completo"} className="w-full px-5 py-3.5 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:border-brand-500 outline-none transition-all" />
                    <input required type="email" placeholder={isEn ? "Work Email" : "Correo de Trabajo"} className="w-full px-5 py-3.5 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:border-brand-500 outline-none transition-all" />
                  </div>
                </div>

                {/* Payment Section (Stripe Elements Mockup) */}
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                      <CreditCard size={16} /> {t.paymentMethod}
                    </h3>
                    <div className="flex gap-2">
                      <div className="w-8 h-5 bg-gray-100 dark:bg-gray-700 rounded-sm"></div>
                      <div className="w-8 h-5 bg-gray-100 dark:bg-gray-700 rounded-sm"></div>
                      <div className="w-8 h-5 bg-gray-100 dark:bg-gray-700 rounded-sm"></div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="relative">
                      <input 
                        required 
                        type="text" 
                        maxLength={19} 
                        placeholder={t.placeholder.card} 
                        className="w-full pl-12 pr-4 py-4 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 outline-none transition-all font-mono" 
                      />
                      <CreditCard size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <input required type="text" maxLength={5} placeholder={t.placeholder.expiry} className="w-full px-4 py-4 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 outline-none transition-all font-mono text-center" />
                      <input required type="text" maxLength={4} placeholder={t.placeholder.cvc} className="w-full px-4 py-4 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 outline-none transition-all font-mono text-center" />
                      <input required type="text" placeholder={t.placeholder.zip} className="w-full px-4 py-4 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10 outline-none transition-all font-mono text-center" />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-gray-100 dark:border-gray-700">
                  <div className="flex items-start gap-3 p-4 bg-brand-50 dark:bg-brand-900/20 rounded-2xl border border-brand-100 dark:border-brand-800 text-sm text-brand-700 dark:text-brand-300">
                    <Lock size={18} className="shrink-0 mt-0.5" />
                    <p>{t.secureNote}</p>
                  </div>
                </div>

                <button 
                  disabled={isProcessing}
                  type="submit" 
                  className="w-full bg-brand-600 hover:bg-brand-700 disabled:bg-brand-400 text-white font-black text-xl py-5 rounded-2xl transition-all shadow-2xl shadow-brand-500/30 flex items-center justify-center gap-3 active:scale-[0.98]"
                >
                  {isProcessing ? <Loader2 size={24} className="animate-spin" /> : <>{t.payNow} - ${currentPrice.toLocaleString()}</>}
                </button>
              </form>
            </div>

            <div className="flex justify-center items-center gap-12 opacity-30 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
               <div className="flex flex-col items-center">
                 <ShieldCheck size={32} />
                 <span className="text-[10px] font-bold mt-2 uppercase tracking-widest">PCI DSS</span>
               </div>
               <div className="flex flex-col items-center">
                 <Lock size={32} />
                 <span className="text-[10px] font-bold mt-2 uppercase tracking-widest">NIST SP-800</span>
               </div>
               <div className="flex flex-col items-center">
                 <div className="font-black text-xl">OWASP</div>
                 <span className="text-[10px] font-bold mt-1 uppercase tracking-widest">Compliant</span>
               </div>
            </div>
          </div>

          {/* Right: Order Summary */}
          <div className="lg:col-span-5">
            <div className="bg-gray-900 text-white rounded-[2.5rem] p-10 sticky top-32 shadow-2xl overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-brand-600/20 rounded-full blur-[80px]"></div>
               
               <h2 className="text-2xl font-bold mb-8 relative z-10">{t.orderSummary}</h2>
               
               <div className="space-y-6 relative z-10">
                  <div className="bg-white/5 p-6 rounded-2xl border border-white/10">
                    <div className="text-sm font-bold text-brand-400 uppercase tracking-widest mb-4">Selected Plan</div>
                    <select 
                      value={selectedService} 
                      onChange={(e) => {
                        const newPlan = e.target.value as PlanKey;
                        setSelectedService(newPlan);
                        if (onSetPlan) onSetPlan(newPlan);
                      }}
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-lg font-bold outline-none focus:border-brand-400 transition-all appearance-none cursor-pointer"
                    >
                      <option value="logistics" className="bg-gray-900">{t.plans.logistics}</option>
                      <option value="itsupport_l1" className="bg-gray-900">{t.plans.itsupport_l1}</option>
                      <option value="itsupport_l2" className="bg-gray-900">{t.plans.itsupport_l2}</option>
                      <option value="admin" className="bg-gray-900">{t.plans.admin}</option>
                      <option value="relations" className="bg-gray-900">{t.plans.relations}</option>
                    </select>
                  </div>

                  <div className="space-y-4 px-2">
                    <div className="flex justify-between text-gray-400">
                      <span>{t.service}</span>
                      <span className="text-white font-medium">{t.plans[selectedService]}</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Setup Fee</span>
                      <span className="text-white font-medium">$0.00</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Tax (0%)</span>
                      <span className="text-white font-medium">$0.00</span>
                    </div>
                  </div>

                  <div className="pt-8 border-t border-white/10 flex justify-between items-end">
                    <div>
                      <div className="text-gray-400 text-sm mb-1">{t.total}</div>
                      <div className="text-5xl font-black">${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    </div>
                    <div className="text-xs text-brand-400 font-bold uppercase tracking-widest mb-2">/ month</div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;