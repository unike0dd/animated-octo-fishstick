import React, { useState } from 'react';
import { Settings, Save, Check } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface ConsentProps {
  language: Language;
}

const Consent: React.FC<ConsentProps> = ({ language }) => {
  const t = translations[language].legal;
  const isEn = language === 'EN';

  const [preferences, setPreferences] = useState({
    essential: true,
    performance: true,
    marketing: false,
    analytics: false
  });
  
  const [saved, setSaved] = useState(false);

  const handleToggle = (key: keyof typeof preferences) => {
    if (key === 'essential') return;
    setPreferences(prev => ({ ...prev, [key]: !prev[key] }));
    setSaved(false);
  };

  const handleSave = () => {
    setTimeout(() => {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }, 500);
  };

  const categories = [
    {
      id: 'essential',
      title: isEn ? 'Strictly Necessary' : 'Estrictamente Necesarias',
      desc: isEn ? 'Essential for functioning.' : 'Esenciales para el funcionamiento.',
      locked: true
    },
    {
      id: 'performance',
      title: isEn ? 'Performance' : 'Rendimiento',
      desc: isEn ? 'Memory of choices.' : 'Recordatorio de elecciones.',
      locked: false
    }
  ];

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="bg-white dark:bg-gray-800 py-16 border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 mb-6">
            <Settings size={32} />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">{t.consentTitle}</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            {isEn ? 'Manage your privacy settings.' : 'Administre sus configuraciones de privacidad.'}
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
          <div className="p-8 border-b border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">{isEn ? 'Cookie Settings' : 'Ajustes de Cookies'}</h2>
          </div>
          
          <div className="divide-y divide-gray-100 dark:divide-gray-700">
            {categories.map((cat) => (
              <div key={cat.id} className="p-8 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                <div className="flex items-start justify-between gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                       <h3 className="font-bold text-gray-900 dark:text-white text-lg">{cat.title}</h3>
                       {cat.locked && (
                         <span className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 px-2 py-0.5 rounded border border-gray-200 dark:border-gray-600 uppercase tracking-wide font-medium">{t.required}</span>
                       )}
                    </div>
                    <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{cat.desc}</p>
                  </div>
                  
                  <button
                    onClick={() => handleToggle(cat.id as keyof typeof preferences)}
                    disabled={cat.locked}
                    className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      preferences[cat.id as keyof typeof preferences] ? 'bg-brand-600' : 'bg-gray-200 dark:bg-gray-600'
                    } ${cat.locked ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                        preferences[cat.id as keyof typeof preferences] ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="p-8 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-100 dark:border-gray-700 flex justify-end gap-4">
             <button 
               onClick={() => {
                 setPreferences({ essential: true, performance: true, marketing: true, analytics: true });
                 setSaved(false);
               }}
               className="px-6 py-2.5 rounded-lg font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
             >
               {t.acceptAll}
             </button>
             <button 
               onClick={handleSave}
               className="bg-brand-600 hover:bg-brand-700 text-white px-8 py-2.5 rounded-lg font-medium shadow-sm transition-all flex items-center gap-2"
             >
               {saved ? <><Check size={18} /> {isEn ? 'Saved' : 'Guardado'}</> : <><Save size={18} /> {t.save}</>}
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Consent;