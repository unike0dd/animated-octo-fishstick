import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, AlertCircle, Database, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Language } from '../types';
import { translations } from '../translations';

interface ContactProps {
  language: Language;
}

interface FormState {
  fullName: string;
  email: string;
  companyName: string;
  phone: string;
  serviceInterest: string;
  message: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  message?: string;
}

const Contact: React.FC<ContactProps> = ({ language }) => {
  const t = translations[language].contact;
  const [formData, setFormData] = useState<FormState>({
    fullName: '', email: '', companyName: '', phone: '', serviceInterest: 'Select a service', message: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [submissionRef, setSubmissionRef] = useState('');

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    if (!formData.fullName || formData.fullName.length < 2) newErrors.fullName = 'Required (min 2 chars).';
    if (!formData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Valid email required.';
    if (!formData.message || formData.message.length < 10) newErrors.message = 'Message required (min 10 chars).';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setIsSubmitting(true);
      // Simulate API call
      setTimeout(() => {
        setSubmissionRef('GAB-' + Math.random().toString(36).substr(2, 9).toUpperCase());
        setShowSuccessModal(true);
        setFormData({ fullName: '', email: '', companyName: '', phone: '', serviceInterest: 'Select a service', message: '' });
        setIsSubmitting(false);
      }, 1500);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) setErrors(prev => ({ ...prev, [name]: undefined }));
  };

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <AnimatePresence>
        {showSuccessModal && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowSuccessModal(false)} className="absolute inset-0 bg-black/80 backdrop-blur-xl" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 40 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 40 }} className="relative bg-white dark:bg-gray-800 rounded-[2rem] p-12 shadow-[0_0_60px_-15px_rgba(0,0,0,0.5)] max-w-md w-full text-center z-10 border border-brand-100 dark:border-brand-900">
              <button onClick={() => setShowSuccessModal(false)} className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                <X size={24} />
              </button>
              <div className="w-24 h-24 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                <CheckCircle2 size={56} />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Request Received</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
                Thank you for your interest. An expert will review your requirements and reach out within 2 business hours.
              </p>
              <div className="bg-gray-50 dark:bg-gray-900/50 py-3 px-6 rounded-2xl mb-10 flex items-center justify-center gap-3 text-sm font-mono text-brand-700 dark:text-brand-300 border border-gray-100 dark:border-gray-800 shadow-sm">
                <Database size={16} /> ID: {submissionRef}
              </div>
              <button onClick={() => setShowSuccessModal(false)} className="w-full bg-brand-600 hover:bg-brand-700 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-brand-500/30 active:scale-95">
                Close
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <section className="bg-white dark:bg-gray-800 py-20 text-center border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4">
          <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-5xl font-bold text-gray-900 dark:text-white mb-6 tracking-tight">{t.heroTitle}</motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="text-2xl text-gray-600 dark:text-gray-300 font-light leading-relaxed">{t.heroSubtitle}</motion.p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="bg-white dark:bg-gray-800 p-10 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">{t.formTitle}</h2>
            <form onSubmit={handleSubmit} className="space-y-8" noValidate>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <label className="block">
                  <span className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 uppercase tracking-widest">{t.fullName} *</span>
                  <input name="fullName" type="text" value={formData.fullName} onChange={handleChange} placeholder="John Doe" className={`w-full px-5 py-4 rounded-2xl border ${errors.fullName ? 'border-red-500 ring-red-100' : 'border-gray-200 dark:border-gray-600 focus:ring-brand-100'} bg-white dark:bg-gray-700 dark:text-white focus:border-brand-500 focus:ring-4 outline-none transition-all shadow-sm`} />
                  {errors.fullName && <p className="mt-2 text-xs text-red-500 flex items-center gap-1 font-bold"><AlertCircle size={14} /> {errors.fullName}</p>}
                </label>
                <label className="block">
                  <span className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 uppercase tracking-widest">{t.email} *</span>
                  <input name="email" type="email" value={formData.email} onChange={handleChange} placeholder="john@company.com" className={`w-full px-5 py-4 rounded-2xl border ${errors.email ? 'border-red-500 ring-red-100' : 'border-gray-200 dark:border-gray-600 focus:ring-brand-100'} bg-white dark:bg-gray-700 dark:text-white focus:border-brand-500 focus:ring-4 outline-none transition-all shadow-sm`} />
                  {errors.email && <p className="mt-2 text-xs text-red-500 flex items-center gap-1 font-bold"><AlertCircle size={14} /> {errors.email}</p>}
                </label>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <label className="block">
                  <span className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 uppercase tracking-widest">{t.company}</span>
                  <input name="companyName" type="text" value={formData.companyName} onChange={handleChange} placeholder="Acme Corp" className="w-full px-5 py-4 rounded-2xl border border-gray-200 dark:border-gray-600 focus:border-brand-500 focus:ring-4 focus:ring-brand-100 bg-white dark:bg-gray-700 dark:text-white outline-none transition-all shadow-sm" />
                </label>
                <label className="block">
                  <span className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 uppercase tracking-widest">{t.phone}</span>
                  <input name="phone" type="tel" value={formData.phone} onChange={handleChange} placeholder="+1 (555) 000-0000" className="w-full px-5 py-4 rounded-2xl border border-gray-200 dark:border-gray-600 focus:border-brand-500 focus:ring-4 focus:ring-brand-100 bg-white dark:bg-gray-700 dark:text-white outline-none transition-all shadow-sm" />
                </label>
              </div>
              <label className="block">
                <span className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 uppercase tracking-widest">{t.interest}</span>
                <select name="serviceInterest" value={formData.serviceInterest} onChange={handleChange} className="w-full px-5 py-4 rounded-2xl border border-gray-200 dark:border-gray-600 focus:border-brand-500 focus:ring-4 focus:ring-brand-100 bg-white dark:bg-gray-700 dark:text-white outline-none transition-all cursor-pointer shadow-sm">
                  <option disabled>Select a service</option>
                  <option>Logistics Management</option>
                  <option>IT Support</option>
                  <option>C-Level Admin Support</option>
                  <option>Customer Relations</option>
                </select>
              </label>
              <label className="block">
                <span className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2 uppercase tracking-widest">{t.message} *</span>
                <textarea name="message" rows={5} value={formData.message} onChange={handleChange} placeholder="How can we help you scale?" className={`w-full px-5 py-4 rounded-2xl border ${errors.message ? 'border-red-500 ring-red-100' : 'border-gray-200 dark:border-gray-600 focus:ring-brand-100'} bg-white dark:bg-gray-700 dark:text-white focus:border-brand-500 focus:ring-4 outline-none transition-all resize-none shadow-sm`}></textarea>
                {errors.message && <p className="mt-2 text-xs text-red-500 flex items-center gap-1 font-bold"><AlertCircle size={14} /> {errors.message}</p>}
              </label>
              <button type="submit" disabled={isSubmitting} className="w-full bg-brand-600 hover:bg-brand-700 disabled:bg-brand-400 text-white font-black text-xl py-5 rounded-2xl transition-all shadow-2xl shadow-brand-500/30 flex items-center justify-center gap-3 active:scale-[0.98]">
                {isSubmitting ? <div className="w-7 h-7 border-4 border-white/30 border-t-white rounded-full animate-spin"></div> : <>{t.submit} <Send size={24} /></>}
              </button>
            </form>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-10">{t.infoTitle}</h2>
              <div className="space-y-10">
                <div className="flex items-start gap-6 group">
                  <div className="w-14 h-14 bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-2xl flex items-center justify-center shrink-0 shadow-sm group-hover:bg-brand-600 group-hover:text-white transition-all duration-300">
                    <Mail size={28} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white text-xl mb-1">Direct Outreach</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-lg">contact@gabriel-services.com</p>
                  </div>
                </div>
                <div className="flex items-start gap-6 group">
                  <div className="w-14 h-14 bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-2xl flex items-center justify-center shrink-0 shadow-sm group-hover:bg-brand-600 group-hover:text-white transition-all duration-300">
                    <Phone size={28} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white text-xl mb-1">Support Line</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-lg">+1 (555) 123-4567</p>
                  </div>
                </div>
                <div className="flex items-start gap-6 group">
                  <div className="w-14 h-14 bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-2xl flex items-center justify-center shrink-0 shadow-sm group-hover:bg-brand-600 group-hover:text-white transition-all duration-300">
                    <MapPin size={28} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white text-xl mb-1">Global HQ</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-lg">123 Business Avenue, Suite 456</p>
                    <p className="text-gray-600 dark:text-gray-400">San Francisco, CA 94105</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-900 text-white p-10 rounded-[2.5rem] relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 w-64 h-64 bg-brand-600/20 rounded-full blur-[80px]"></div>
              <h3 className="font-bold text-2xl mb-4 relative z-10">Scale Strategy</h3>
              <p className="text-gray-400 mb-8 relative z-10 text-lg leading-relaxed">
                Our team acts as a seamless extension of your workforce, deploying precision operations in under 48 hours.
              </p>
              <div className="flex items-center gap-3 text-brand-400 font-bold text-base relative z-10">
                <Database size={20} /> System Uptime: 99.99%
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;