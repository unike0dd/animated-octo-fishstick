import React from 'react';
import { ShieldCheck, Lock, FileText, UserCheck } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface GDPRProps {
  language: Language;
}

const GDPR: React.FC<GDPRProps> = ({ language }) => {
  const t = translations[language].legal;
  const isEn = language === 'EN';

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="bg-white dark:bg-gray-800 py-16 border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 mb-6">
            <ShieldCheck size={32} />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">{t.gdprTitle}</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            {isEn 
              ? 'We are committed to transparency and ensuring your data rights are respected under the General Data Protection Regulation.'
              : 'Estamos comprometidos con la transparencia y con garantizar que se respeten sus derechos de datos bajo el Reglamento General de Protección de Datos.'}
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
             <Lock className="text-brand-600 dark:text-brand-400 mb-4" size={28} />
             <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{isEn ? 'Data Protection' : 'Protección de Datos'}</h3>
             <p className="text-gray-600 dark:text-gray-400">{isEn ? 'State-of-the-art security measures.' : 'Medidas de seguridad de última generación.'}</p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
             <UserCheck className="text-brand-600 dark:text-brand-400 mb-4" size={28} />
             <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{isEn ? 'Your Control' : 'Su Control'}</h3>
             <p className="text-gray-600 dark:text-gray-400">{isEn ? 'Full control over your data.' : 'Control total sobre sus datos.'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GDPR;