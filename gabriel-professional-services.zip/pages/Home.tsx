import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, TrendingUp, Award, Rocket, Check, Database, Activity, ArrowRight, Lightbulb, Compass, BarChart } from 'lucide-react';
import Hero3D from '../components/Hero3D';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface HomeProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const Home: React.FC<HomeProps> = ({ onNavigate, language }) => {
  // Use a fallback to 'EN' if language lookup fails to prevent "undefined" errors
  const t = (translations[language] || translations['EN']).home;

  const features = [
    {
      icon: TrendingUp,
      title: language === 'EN' ? 'Operational Velocity' : 'Velocidad Operativa',
      description: language === 'EN' ? 'Stop waiting for results. We deploy teams in 48 hours to handle your growth surges.' : 'Deja de esperar resultados. Desplegamos equipos en 48 horas para manejar tus picos de crecimiento.',
      items: language === 'EN' 
        ? ['48-hour onboarding', 'Scale up or down monthly', 'Success-based KPIs']
        : ['Incorporación en 48 horas', 'Escala mensual', 'KPIs basados en éxito']
    },
    {
      icon: Shield,
      title: language === 'EN' ? 'De-Risk Your Expansion' : 'Reduce el Riesgo de tu Expansión',
      description: language === 'EN' ? 'We handle compliance, HR, and overhead so you can enter new markets with zero liability.' : 'Manejamos cumplimiento, RR.HH. y gastos generales para que entres a nuevos mercados sin responsabilidades.',
      items: language === 'EN'
        ? ['GDPR & SOC 2 Compliant', 'Zero HR overhead', 'Total liability protection']
        : ['Cumple con RGPD y SOC 2', 'Cero gastos de RR.HH.', 'Protección total de responsabilidad']
    }
  ];

  const insights = [
    { icon: Lightbulb, ...t.insight1, color: 'text-yellow-500', bg: 'bg-yellow-50 dark:bg-yellow-900/20' },
    { icon: BarChart, ...t.insight2, color: 'text-brand-500', bg: 'bg-brand-50 dark:bg-brand-900/20' },
    { icon: Compass, ...t.insight3, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-900/20' }
  ];

  const systemMetrics = [
    { label: 'API Uptime', value: '99.99%', icon: Activity, color: 'text-green-500' },
    { label: 'Processing Speed', value: '< 20ms', icon: Database, color: 'text-brand-500' },
    { label: 'Security Score', value: 'A+', icon: Shield, color: 'text-blue-500' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        <Hero3D />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-50/80 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 text-sm font-medium mb-8 border border-brand-100 dark:border-brand-800 backdrop-blur-md">
                <Rocket size={14} className="animate-bounce" />
                {t.badge}
            </div>
            <h1 className="text-6xl md:text-8xl font-extrabold text-gray-900 dark:text-white mb-6 tracking-tight leading-tight">
              {t.title} <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 via-brand-400 to-blue-500">{t.titleSuffix}</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-10 max-w-3xl mx-auto leading-relaxed font-light">
              {t.subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-5 justify-center items-center">
              <button 
                onClick={() => onNavigate('contact')}
                className="bg-brand-600 hover:bg-brand-700 text-white px-10 py-5 rounded-2xl font-bold text-lg shadow-2xl shadow-brand-500/30 hover:shadow-brand-500/50 transition-all transform hover:-translate-y-1 active:scale-95 flex items-center gap-2"
              >
                {t.demo} <ArrowRight size={20} />
              </button>
              <button 
                onClick={() => onNavigate('services')}
                className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-md hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-800 dark:text-white border border-gray-200 dark:border-gray-700 px-10 py-5 rounded-2xl font-bold text-lg shadow-sm hover:shadow-xl transition-all"
              >
                {t.explore}
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Scaling Insights Section */}
      <section className="py-24 bg-white dark:bg-gray-900 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">{t.insightTitle}</h2>
              <div className="w-24 h-1 bg-brand-500 mx-auto rounded-full"></div>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {insights.map((insight, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-3xl border border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50 hover:bg-white dark:hover:bg-gray-800 transition-all shadow-sm hover:shadow-xl group"
                >
                  <div className={`w-14 h-14 ${insight.bg} ${insight.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <insight.icon size={28} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{insight.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{insight.text}</p>
                </motion.div>
              ))}
           </div>
        </div>
      </section>

      {/* Modern Features Section */}
      <section className="py-32 bg-gray-50 dark:bg-gray-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: idx === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="p-10 rounded-3xl bg-white dark:bg-gray-800 shadow-2xl shadow-brand-500/5 border border-gray-100 dark:border-gray-700"
              >
                <div className="w-16 h-16 bg-brand-600 text-white rounded-2xl flex items-center justify-center mb-8">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed text-lg">{feature.description}</p>
                <div className="space-y-3">
                  {feature.items.map((item, i) => (
                    <div key={i} className="flex items-center gap-3 text-gray-700 dark:text-gray-300 font-medium">
                      <div className="w-5 h-5 rounded-full bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 flex items-center justify-center">
                        <Check size={12} />
                      </div>
                      {item}
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* System Metrics Banner */}
      <section className="py-12 bg-white dark:bg-gray-900 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-center gap-12 md:gap-24 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
           {systemMetrics.map((metric, i) => (
             <div key={i} className="flex items-center gap-3">
               <metric.icon size={20} className={metric.color} />
               <div>
                 <div className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-widest font-bold">{metric.label}</div>
                 <div className="text-xl font-bold text-gray-900 dark:text-white">{metric.value}</div>
               </div>
             </div>
           ))}
        </div>
      </section>

      {/* Global CTA */}
      <section className="py-32 bg-brand-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-5xl font-bold text-white mb-8"
          >
            {t.ctaTitle}
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-brand-100 text-2xl mb-12 font-light"
          >
            {t.ctaSubtitle}
          </motion.p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onNavigate('contact')}
              className="bg-white text-brand-700 hover:bg-gray-100 px-12 py-5 rounded-2xl font-bold text-xl shadow-2xl transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
            >
              {t.demo} <ArrowRight size={24} />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;