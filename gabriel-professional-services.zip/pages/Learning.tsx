import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GraduationCap, ArrowRight, Search, X, User, Mail, Globe, Phone, CheckCircle2, Send, BookOpen, Download, FileCheck } from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sphere, MeshDistortMaterial, Float } from '@react-three/drei';
import * as THREE from 'three';
import { Page, Language } from '../types';
import { translations } from '../translations';

interface LearningProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  language: Language;
}

// 3D Animation for the download progress
const DownloadProgress3D = ({ progress }: { progress: number }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state, delta) => {
    if (meshRef.current) {
      // Rotation speed increases with progress
      const speed = 0.5 + (progress / 100) * 3;
      meshRef.current.rotation.y += delta * speed;
      meshRef.current.rotation.x += delta * (speed / 2);
    }
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={1}>
      <mesh ref={meshRef}>
        <sphereGeometry args={[1.2, 32, 32]} />
        <meshStandardMaterial 
          color="#7c3aed" 
          wireframe 
          emissive="#7c3aed" 
          emissiveIntensity={progress / 100}
          transparent
          opacity={0.6}
        />
      </mesh>
      {/* Internal Core */}
      <Sphere args={[0.5, 32, 32]}>
        <MeshDistortMaterial
          color="#a78bfa"
          distort={0.4}
          speed={2}
          roughness={0}
        />
      </Sphere>
    </Float>
  );
};

const JoinHubModal = ({ isOpen, onClose, language }: { isOpen: boolean; onClose: () => void; language: Language }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    country: '',
    phone: '',
    topic: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadFinished, setDownloadFinished] = useState(false);
  
  const isEn = language === 'EN';
  const t = (translations[language] || translations['EN']).learning;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  const startDownload = () => {
    setIsDownloading(true);
    let current = 0;
    const interval = setInterval(() => {
      current += Math.random() * 8;
      if (current >= 100) {
        current = 100;
        setDownloadProgress(100);
        clearInterval(interval);
        setTimeout(() => {
          setIsDownloading(false);
          setDownloadFinished(true);
        }, 500);
      } else {
        setDownloadProgress(Math.floor(current));
      }
    }, 200);
  };

  const resetModal = () => {
    onClose();
    setTimeout(() => {
      setIsSuccess(false);
      setIsDownloading(false);
      setDownloadFinished(false);
      setDownloadProgress(0);
      setFormData({ firstName: '', lastName: '', email: '', country: '', phone: '', topic: '' });
    }, 300);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={resetModal}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-white dark:bg-gray-800 w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden z-10 p-8 md:p-12 border border-brand-100 dark:border-brand-900/30"
          >
            <button
              onClick={resetModal}
              className="absolute top-6 right-6 p-2 text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors z-20"
            >
              <X size={24} />
            </button>

            {isDownloading ? (
              <div className="text-center py-4">
                <div className="h-64 mb-8">
                  <Canvas camera={{ position: [0, 0, 4] }}>
                    <ambientLight intensity={1} />
                    <pointLight position={[10, 10, 10]} />
                    <DownloadProgress3D progress={downloadProgress} />
                  </Canvas>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {isEn ? 'Processing Sequence...' : 'Procesando Secuencia...'}
                </h3>
                <div className="text-5xl font-black text-brand-600 dark:text-brand-400 mb-6 font-mono">
                  {downloadProgress}%
                </div>
                <div className="w-full bg-gray-100 dark:bg-gray-700 h-2 rounded-full overflow-hidden mb-4">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${downloadProgress}%` }}
                    className="h-full bg-brand-600"
                  />
                </div>
                <p className="text-gray-500 dark:text-gray-400 animate-pulse text-sm uppercase tracking-widest font-bold">
                  {formData.topic}
                </p>
              </div>
            ) : isSuccess ? (
              <div className="text-center py-4">
                <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                  {downloadFinished ? <FileCheck size={48} /> : <CheckCircle2 size={48} />}
                </div>
                <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                  {downloadFinished 
                    ? (isEn ? 'Ready for Review' : 'Listo para Revisar')
                    : (isEn ? 'Registration Complete' : 'Registro Completo')}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-10 text-lg">
                  {downloadFinished 
                    ? (isEn ? 'Your curriculum has been compiled and is ready for use.' : 'Su plan de estudios ha sido compilado y está listo para su uso.')
                    : (isEn ? 'Thank you for joining. You can now download your specialized material.' : 'Gracias por unirse. Ahora puede descargar su material especializado.')}
                </p>
                
                {downloadFinished ? (
                   <div className="space-y-4">
                    <button
                      onClick={resetModal}
                      className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-4 rounded-2xl transition-all shadow-xl shadow-brand-500/20"
                    >
                      {isEn ? 'Open Learning Path' : 'Abrir Ruta de Aprendizaje'}
                    </button>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {isEn ? 'A copy has been sent to ' : 'Se ha enviado una copia a '} <strong>{formData.email}</strong>
                    </p>
                   </div>
                ) : (
                  <button
                    onClick={startDownload}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-5 rounded-2xl transition-all shadow-2xl shadow-indigo-500/30 flex items-center justify-center gap-3 transform hover:-translate-y-1 active:scale-95"
                  >
                    <Download size={22} /> {isEn ? `Download ${formData.topic}` : `Descargar ${formData.topic}`}
                  </button>
                )}
              </div>
            ) : (
              <>
                <div className="text-center mb-10">
                  <div className="w-16 h-16 bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-brand-100 dark:border-brand-800">
                    <GraduationCap size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    {isEn ? 'Join the Learning Hub' : 'Únete al Centro de Aprendizaje'}
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 mt-2">
                    {isEn ? 'Gain access to premium operational resources.' : 'Obtén acceso a recursos operativos premium.'}
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <label className="block">
                      <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 block px-1">
                        {isEn ? 'First Name' : 'Nombre'}
                      </span>
                      <div className="relative">
                        <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input required name="firstName" value={formData.firstName} onChange={handleInputChange} type="text" placeholder="John" className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 dark:text-white outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all text-sm" />
                      </div>
                    </label>
                    <label className="block">
                      <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 block px-1">
                        {isEn ? 'Last Name' : 'Apellido'}
                      </span>
                      <div className="relative">
                        <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input required name="lastName" value={formData.lastName} onChange={handleInputChange} type="text" placeholder="Doe" className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 dark:text-white outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all text-sm" />
                      </div>
                    </label>
                  </div>

                  <label className="block">
                    <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 block px-1">
                      {isEn ? 'Work Email' : 'Correo de Trabajo'}
                    </span>
                    <div className="relative">
                      <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input required name="email" value={formData.email} onChange={handleInputChange} type="email" placeholder="john@company.com" className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 dark:text-white outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all text-sm" />
                    </div>
                  </label>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="block">
                      <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 block px-1">
                        {isEn ? 'Country' : 'País'}
                      </span>
                      <div className="relative">
                        <Globe size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        <select required name="country" value={formData.country} onChange={handleInputChange} className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 dark:text-white outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all appearance-none cursor-pointer text-sm">
                          <option value="">{isEn ? 'Select country' : 'Selecciona país'}</option>
                          <option value="US">United States</option>
                          <option value="UK">United Kingdom</option>
                          <option value="ES">Spain</option>
                          <option value="MX">Mexico</option>
                          <option value="CA">Canada</option>
                        </select>
                      </div>
                    </label>

                    <label className="block">
                      <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 block px-1">
                        {isEn ? 'Topic' : 'Tema'}
                      </span>
                      <div className="relative">
                        <BookOpen size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        <select required name="topic" value={formData.topic} onChange={handleInputChange} className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 dark:text-white outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all appearance-none cursor-pointer text-sm">
                          <option value="">{isEn ? 'Select topic' : 'Selecciona tema'}</option>
                          {t.modules.map((m: any, i: number) => (
                            <option key={i} value={m.title}>{m.title}</option>
                          ))}
                        </select>
                      </div>
                    </label>
                  </div>

                  <label className="block">
                    <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 block px-1">
                      {isEn ? 'Phone Number' : 'Número de Teléfono'}
                    </span>
                    <div className="relative">
                      <Phone size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input required name="phone" value={formData.phone} onChange={handleInputChange} type="tel" placeholder="+1 (555) 000-0000" className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 dark:text-white outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all text-sm" />
                    </div>
                  </label>

                  <button
                    disabled={isSubmitting}
                    type="submit"
                    className="w-full mt-4 bg-brand-600 hover:bg-brand-700 disabled:bg-brand-400 text-white font-black text-lg py-4 rounded-xl transition-all shadow-xl shadow-brand-500/30 flex items-center justify-center gap-3 active:scale-[0.98]"
                  >
                    {isSubmitting ? (
                      <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <>{isEn ? 'Access Hub' : 'Acceder al Centro'} <Send size={20} /></>
                    )}
                  </button>
                </form>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const Learning: React.FC<LearningProps> = ({ onNavigate, language }) => {
  const t = (translations[language] || translations['EN']).learning;
  const [activeCategory, setActiveCategory] = useState(t.categories[0]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="pt-20 min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <JoinHubModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} language={language} />

      {/* Learning Hero */}
      <section className="bg-white dark:bg-gray-800 py-16 text-center border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            {t.heroTitle}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 dark:text-gray-300"
          >
            {t.heroSubtitle}
          </motion.p>
        </div>
      </section>

      {/* Filter & Search Bar */}
      <section className="py-8 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 sticky top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-wrap justify-center gap-3">
            {t.categories.map((cat: string) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                  activeCategory === cat
                    ? 'bg-brand-600 text-white shadow-lg'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-brand-50 dark:hover:bg-brand-900/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-64">
             <Search className="absolute left-3 top-3 text-gray-400" size={18} />
             <input 
               type="text" 
               placeholder={language === 'EN' ? 'Search hub...' : 'Buscar en el centro...'}
               className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 outline-none focus:ring-2 focus:ring-brand-200 dark:text-white"
             />
          </div>
        </div>
      </section>

      {/* Learning Grid */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {t.modules.filter((m: any) => activeCategory === t.categories[0] || m.category === activeCategory).map((module: any, idx: number) => (
            <motion.article 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 group hover:shadow-xl transition-all flex flex-col"
            >
              <div className="h-40 bg-gray-900 relative flex items-center justify-center overflow-hidden shrink-0">
                 <div className="absolute inset-0 bg-gradient-to-br from-brand-900 to-indigo-900 opacity-80"></div>
                 
                 <div className="relative z-10 text-white flex flex-col items-center">
                    <i className={`${module.icon} text-4xl mb-3 text-brand-400 group-hover:scale-110 transition-transform`}></i>
                    <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">{module.category}</span>
                 </div>
                 
                 <div className="absolute bottom-4 left-4 right-4 h-1 bg-white/20 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      whileInView={{ width: '100%' }}
                      transition={{ duration: 1.5, delay: 0.5 }}
                      className="h-full bg-brand-500"
                    />
                 </div>
              </div>

              <div className="p-8 flex-grow flex flex-col">
                <div className="flex items-center gap-4 text-[10px] font-bold text-gray-500 dark:text-gray-400 mb-4 uppercase tracking-wider">
                  <span className="flex items-center gap-1.5"><i className="fas fa-clock text-brand-500"></i> {module.duration}</span>
                  <span className="px-2 py-0.5 rounded bg-brand-50 dark:bg-brand-900/40 text-brand-600 dark:text-brand-400">Advanced Path</span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  {module.title}
                </h3>
                
                <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm leading-relaxed flex-grow">
                  {module.excerpt}
                </p>
                
                <button className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-bold text-sm hover:gap-3 transition-all mt-auto group/btn">
                  {t.readMore} 
                  <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Certification CTA */}
      <section className="py-24 bg-gray-900 text-white text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-brand-600/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px]"></div>
        
        <div className="max-w-3xl mx-auto px-4 relative z-10">
          <div className="mb-6 inline-flex p-5 rounded-full bg-brand-600/20 text-brand-400 shadow-2xl border border-brand-500/20">
            <GraduationCap size={48} />
          </div>
          <h2 className="text-4xl font-bold mb-6">
            {language === 'EN' ? 'Scale Smarter, Not Harder' : 'Escala de Forma más Inteligente'}
          </h2>
          <p className="text-gray-400 text-xl mb-12 font-light">
            {language === 'EN' 
              ? 'Our industry-certified curriculum provides your team with the precision tools needed to manage high-velocity scaling.' 
              : 'Nuestro plan de estudios certificado por la industria proporciona a su equipo las herramientas de precisión necesarias para gestionar un escalamiento de alta velocidad.'}
          </p>
          <div className="flex justify-center">
             <button 
               onClick={() => setIsModalOpen(true)}
               className="bg-brand-600 hover:bg-brand-700 text-white px-12 py-5 rounded-2xl font-black text-lg transition-all shadow-2xl shadow-brand-500/30 flex items-center justify-center gap-3 transform hover:-translate-y-1 active:scale-95"
             >
                <i className="fas fa-right-to-bracket"></i> {language === 'EN' ? 'Join the Hub' : 'Unirse al Centro'}
             </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Learning;