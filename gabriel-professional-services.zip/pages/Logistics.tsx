
import React from 'react';
import { Truck, Map, Box, BarChart3, Clock, CheckCircle } from 'lucide-react';
import { Page, Language } from '../types';
import { translations } from '../translations';
import Logistics3D from '../components/Logistics3D';

interface LogisticsProps {
    onNavigate: (page: Page, sectionId?: string) => void;
    language: Language;
}

const Logistics: React.FC<LogisticsProps> = ({ onNavigate, language }) => {
  const t = (translations[language] || translations['EN']).services.pages.logistics;

  const features = [
    { icon: Map, title: t.f1, desc: t.f1d },
    { icon: Truck, title: t.f2, desc: t.f2d },
    { icon: Box, title: t.f3, desc: t.f3d },
    { icon: BarChart3, title: t.f4, desc: t.f4d },
    { icon: Clock, title: t.f5, desc: t.f5d },
    { icon: CheckCircle, title: t.f6, desc: t.f6d },
  ];

  return (
    <div className="pt-20 min-h-screen bg-white dark:bg-gray-900 transition-colors">
      <section className="bg-blue-50 dark:bg-blue-900/10 py-20 transition-colors">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-5xl md:text-6xl font-black text-gray-900 dark:text-white mb-6 tracking-tight">
              {t.title}
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto lg:mx-0 mb-8 font-light leading-relaxed">
              {t.subtitle}
            </p>
            <button 
              onClick={() => onNavigate('contact')}
              className="bg-brand-600 hover:bg-brand-700 text-white px-10 py-4 rounded-2xl font-bold transition-all shadow-xl shadow-brand-500/20"
            >
              Request Network Audit
            </button>
          </div>
          <div className="relative">
            <Logistics3D />
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feat, idx) => (
                <div key={idx} className="p-10 border border-gray-100 dark:border-gray-800 rounded-3xl hover:shadow-2xl transition-all bg-white dark:bg-gray-800 group">
                   <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                      <feat.icon size={28} />
                   </div>
                   <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 tracking-tight">{feat.title}</h3>
                   <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{feat.desc}</p>
                </div>
              ))}
           </div>
        </div>
      </section>

      <section className="bg-gray-900 text-white py-24 text-center relative overflow-hidden">
         <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }}></div>
         <div className="relative z-10">
           <h2 className="text-4xl font-bold mb-8 tracking-tight">
             {t.cta}
           </h2>
           <button 
             onClick={() => onNavigate('contact')}
             className="bg-white text-gray-900 px-12 py-5 rounded-2xl font-black text-lg transition-all shadow-2xl hover:scale-105 active:scale-95"
           >
             {t.btn}
           </button>
         </div>
      </section>
    </div>
  );
};

export default Logistics;
