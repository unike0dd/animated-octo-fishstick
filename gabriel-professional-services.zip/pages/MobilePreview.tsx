
import React from 'react';
import { motion } from 'framer-motion';
import { Smartphone, Download, ShieldCheck, Zap, Code2, Layers, Cpu } from 'lucide-react';
import { Page, Language } from '../types';

interface MobilePreviewProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  language: Language;
}

const MobilePreview: React.FC<MobilePreviewProps> = ({ language }) => {
  const isEn = language === 'EN';

  return (
    <div className="pt-20 min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 text-sm font-bold mb-6">
              <Code2 size={16} />
              {isEn ? 'Powered by Flutter & Dart' : 'Impulsado por Flutter y Dart'}
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-gray-900 dark:text-white mb-6 leading-tight tracking-tighter">
              {isEn ? 'High-Velocity' : 'Alta Velocidad'} <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-blue-500">
                {isEn ? 'Web Apps' : 'Aplicaciones Web'}
              </span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-10 leading-relaxed font-light max-w-lg">
              {isEn 
                ? 'Leverage our multi-platform Dart backend and Flutter frontend to deploy beautiful, high-performance web applications in record time.'
                : 'Aprovecha nuestro backend Dart multiplataforma y frontend Flutter para desplegar aplicaciones web hermosas y de alto rendimiento en tiempo récord.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
              <div className="flex gap-4 group">
                <div className="w-12 h-12 rounded-2xl bg-brand-50 dark:bg-brand-900/30 flex items-center justify-center shrink-0 border border-brand-100 dark:border-brand-800 group-hover:bg-brand-600 group-hover:text-white transition-all">
                  <Zap size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 dark:text-white text-lg">{isEn ? 'Skia-Powered' : 'Motor Skia'}</h3>
                  <p className="text-sm text-gray-500">{isEn ? '60 FPS web rendering' : 'Renderizado a 60 FPS'}</p>
                </div>
              </div>
              <div className="flex gap-4 group">
                <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center shrink-0 border border-blue-100 dark:border-blue-800 group-hover:bg-blue-600 group-hover:text-white transition-all">
                  <Layers size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 dark:text-white text-lg">{isEn ? 'Unified Codebase' : 'Base de Código Única'}</h3>
                  <p className="text-sm text-gray-500">{isEn ? 'Web, Mobile & Desktop' : 'Web, Móvil y Escritorio'}</p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <button className="bg-brand-600 hover:bg-brand-700 text-white px-10 py-5 rounded-2xl font-black text-lg transition-all shadow-2xl shadow-brand-500/30 flex items-center gap-3 active:scale-95">
                {isEn ? 'View Dart SDK' : 'Ver SDK de Dart'} <Code2 size={20} />
              </button>
              <button className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 px-10 py-5 rounded-2xl font-bold text-lg hover:shadow-xl transition-all">
                {isEn ? 'Live Demo' : 'Demo en Vivo'}
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative flex justify-center perspective-[1000px]"
          >
            <div className="w-full max-w-[500px] h-[600px] bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] border border-gray-100 dark:border-gray-700 overflow-hidden relative group transform hover:rotate-y-[-5deg] transition-transform duration-700">
               {/* Flutter Simulated App Bar */}
               <div className="h-20 bg-brand-600 flex items-center justify-between px-8 text-white">
                  <div className="font-black text-xl tracking-tighter italic">FlutterWeb</div>
                  <div className="flex gap-4">
                    <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
                    <div className="w-2 h-2 rounded-full bg-white opacity-50"></div>
                  </div>
               </div>
               
               {/* Dashboard Content */}
               <div className="p-8 space-y-8">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="bg-brand-50 dark:bg-brand-900/20 p-6 rounded-3xl border border-brand-100 dark:border-brand-800">
                      <div className="text-brand-600 dark:text-brand-400 text-3xl font-black mb-1">98%</div>
                      <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Perf Score</div>
                    </div>
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-3xl border border-blue-100 dark:border-blue-800">
                      <div className="text-blue-600 dark:text-blue-400 text-3xl font-black mb-1">12ms</div>
                      <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Wasm Latency</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-900/50 rounded-3xl p-8 border border-gray-100 dark:border-gray-800 h-64 relative overflow-hidden">
                     <div className="flex justify-between items-center mb-6">
                        <div className="font-bold text-gray-900 dark:text-white uppercase tracking-widest text-xs">Real-time Stream</div>
                        <div className="text-xs text-brand-500 font-mono">ACTIVE</div>
                     </div>
                     <div className="flex items-end gap-2 h-32">
                        {[40, 70, 45, 90, 65, 80, 55, 95, 75, 85].map((h, i) => (
                          <motion.div 
                            key={i} 
                            initial={{ height: 0 }}
                            animate={{ height: `${h}%` }}
                            transition={{ delay: i * 0.1, duration: 1, repeat: Infinity, repeatType: "reverse" }}
                            className="flex-1 bg-brand-500 rounded-t-lg"
                          />
                        ))}
                     </div>
                  </div>
               </div>
            </div>
            
            {/* Background floating elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-500/20 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
          </motion.div>
        </div>
      </section>

      <section className="bg-gray-900 text-white py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap justify-around gap-12 opacity-50">
           <div className="flex flex-col items-center">
             <div className="text-3xl font-black mb-2">DART</div>
             <div className="text-[10px] font-bold tracking-widest uppercase">Backend</div>
           </div>
           <div className="flex flex-col items-center">
             <div className="text-3xl font-black mb-2">FLUTTER</div>
             <div className="text-[10px] font-bold tracking-widest uppercase">Frontend</div>
           </div>
           <div className="flex flex-col items-center">
             <div className="text-3xl font-black mb-2">THREE.JS</div>
             <div className="text-[10px] font-bold tracking-widest uppercase">Graphics</div>
           </div>
           <div className="flex flex-col items-center">
             <div className="text-3xl font-black mb-2">CLOUDFLARE</div>
             <div className="text-[10px] font-bold tracking-widest uppercase">Edge Deployment</div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default MobilePreview;
