import React from 'react';
import { Rocket, Lock, Mail, ArrowRight, Home } from 'lucide-react';
import { Page, Language } from '../types';
import Hero3D from '../components/Hero3D';
import { translations } from '../translations';

interface SignInProps {
  onNavigate: (page: Page, sectionId?: string) => void;
  language: Language;
}

const SignIn: React.FC<SignInProps> = ({ onNavigate, language }) => {
  const t = (translations[language] || translations['EN']).auth;
  const isEn = language === 'EN';

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-white dark:bg-gray-900 transition-colors relative">
      {/* Back to Home Button - High Visibility Version */}
      <button 
        onClick={() => onNavigate('home')}
        className="absolute top-6 left-6 z-[60] flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-md text-gray-800 dark:text-white border border-gray-200 dark:border-gray-700 transition-all shadow-xl group hover:scale-105 active:scale-95"
      >
        <Home size={18} className="group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors" />
        <span className="font-bold text-sm tracking-wide">{isEn ? 'Back to Home' : 'Volver al Inicio'}</span>
      </button>

      {/* Left Section (Branding) - Hidden on mobile */}
      <div className="hidden md:flex md:w-1/2 bg-gray-900 relative items-center justify-center overflow-hidden">
        <Hero3D />
        <div className="relative z-10 px-12 text-center text-white">
          <div className="w-16 h-16 bg-gradient-to-br from-brand-600 to-brand-400 rounded-2xl flex items-center justify-center text-white mx-auto mb-8 shadow-2xl">
            <Rocket size={40} />
          </div>
          <h2 className="text-4xl font-bold mb-6">{t.welcome}</h2>
          <p className="text-gray-300 text-lg leading-relaxed max-w-md mx-auto">
            {t.welcomeDesc}
          </p>
        </div>
      </div>

      {/* Right Section (Form) */}
      <div className="flex-1 flex items-center justify-center p-8 md:p-12 lg:p-16 dark:bg-gray-900">
        <div className="w-full max-w-md">
          <div className="text-center md:text-left mb-10">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{t.signinTitle}</h1>
            <p className="text-gray-600 dark:text-gray-400">{t.signinSubtitle}</p>
          </div>

          <form className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t.email}</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Mail size={20} />
                </div>
                <input 
                  type="email" 
                  placeholder="name@company.com" 
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t.password}</label>
                <a href="#" className="text-sm font-medium text-brand-600 hover:text-brand-700">{t.forgot}</a>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  <Lock size={20} />
                </div>
                <input 
                  type="password" 
                  placeholder="••••••••" 
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none transition-all"
                />
              </div>
            </div>

            <button type="button" className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2">
              {t.signinTitle} <ArrowRight size={18} />
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-800 text-center">
            <p className="text-gray-600 dark:text-gray-400">
              {t.noAccount}{' '}
              <button 
                onClick={() => onNavigate('getstarted')}
                className="text-brand-600 font-bold hover:underline"
              >
                {t.startTrial}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;