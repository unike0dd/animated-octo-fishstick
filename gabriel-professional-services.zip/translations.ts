export const translations = {
  EN: {
    nav: {
      home: 'Home',
      services: 'Services',
      about: 'About Us',
      careers: 'Careers',
      contact: 'Contact',
      signin: 'Client Portal',
      getstarted: 'Start Scaling',
      submenu: {
        logistics: 'Logistics Management',
        itsupport: 'IT Support Level I & II',
        admin: 'C-Level Admin Support',
        relations: 'Customer Relations'
      }
    },
    checkout: {
      title: 'Secure Checkout',
      subtitle: 'Finalize your fractional operations subscription.',
      billingInfo: 'Billing Information',
      paymentMethod: 'Payment Method',
      orderSummary: 'Order Summary',
      payNow: 'Complete Payment',
      secureNote: 'Your payment is processed securely via Stripe. We are compliant with PCI DSS, NIST, and OWASP standards.',
      success: 'Payment Successful!',
      successDesc: 'Your operational team is being provisioned. You will receive an onboarding email shortly.',
      service: 'Service',
      price: 'Price',
      total: 'Total',
      placeholder: {
        card: 'Card number',
        expiry: 'MM/YY',
        cvc: 'CVC',
        zip: 'ZIP Code'
      },
      prices: {
        logistics: 3799.99,
        itsupport_l1: 3499.99,
        itsupport_l2: 4399.99,
        admin: 2599.99,
        relations: 2359.99
      },
      plans: {
        logistics: 'Logistics Management',
        itsupport_l1: 'IT Support Level I',
        itsupport_l2: 'IT Support Level II',
        admin: 'C-Level Admin Support',
        relations: 'Customer Relations'
      }
    },
    auth: {
      welcome: 'Scale Faster',
      welcomeDesc: 'Access your dedicated operational dashboard and manage your scaling velocity in real-time.',
      signinTitle: 'Sign In',
      signinSubtitle: 'Enter your credentials to access the Gabriel portal.',
      email: 'Work Email',
      password: 'Password',
      forgot: 'Forgot password?',
      noAccount: "Don't have an account?",
      startTrial: 'Start a trial.',
      trialTitle: 'Start Your 14-Day Pilot',
      trialSubtitle: 'Experience the power of fractional operations with no long-term commitment.',
      perks: ['Dedicated Account Manager', '24/7 Support Access', 'Real-time Analytics', 'Custom Workflows'],
      rating: 'rating from 500+ enterprises',
      getStartedTitle: 'Create Your Account',
      step: 'Step',
      firstName: 'First Name',
      lastName: 'Last Name',
      workEmail: 'Work Email',
      phone: 'Phone Number',
      companyName: 'Company Name',
      companySize: 'Company Size',
      primaryInterest: 'Primary Interest',
      continue: 'Continue',
      back: 'Back',
      createAccount: 'Create Account',
      alreadyHave: 'Already have an account?'
    },
    legal: {
      privacyTitle: 'Privacy Policy',
      termsTitle: 'Terms of Service',
      gdprTitle: 'GDPR Compliance',
      consentTitle: 'Consent Preferences',
      lastUpdated: 'Last Updated: February 2026',
      required: 'Required',
      save: 'Save Preferences',
      acceptAll: 'Accept All'
    },
    footer: {
      description: 'Professional business services including logistics, IT support, C-level assistance, and customer relations. Streamlining operations for modern enterprises.',
      services: 'Services',
      company: 'Company',
      contact: 'Contact',
      privacy: 'Privacy Policy',
      terms: 'Terms of Service',
      gdpr: 'GDPR',
      consent: 'Consent Preferences',
      rights: 'All rights reserved.',
      tagline: 'Built for excellence.',
      links: {
        logistics: 'Logistics Management',
        itsupport: 'IT Support',
        admin: 'C-Level Admin',
        relations: 'Customer Relations',
        about: 'About Us',
        careers: 'Careers',
        learning: 'Learning Hub',
        contact: 'Contact'
      }
    },
    home: {
      badge: 'SMB Growth & Scaling Experts',
      title: 'Scale Your Business,',
      titleSuffix: 'Not Your Workload',
      subtitle: 'Reclaim your time and accelerate growth. We provide high-performance operational support so you can focus on the big picture. Precision outsourcing for the modern SMB.',
      explore: 'View Solutions',
      demo: 'Get a Scaling Audit',
      insightTitle: 'Scaling Insights for SMBs',
      insight1: {
        title: 'The 80/20 Delegation',
        text: 'Offload the 80% of repetitive tasks to focus on the 20% of high-impact strategic work.'
      },
      insight2: {
        title: 'Fractional Operations',
        text: 'Access C-level operational expertise without the six-figure full-time salary overhead.'
      },
      insight3: {
        title: 'Global Time-Scaling',
        text: 'Deploy 24/7 workflows that keep your business running while you sleep.'
      },
      ctaTitle: 'Your next phase of growth starts with a conversation.',
      ctaSubtitle: "Don't let operational friction hold back your vision. Let's build your backbone."
    },
    about: {
      heroTitle: 'Excellence in Execution',
      heroSubtitle: 'Helping modern enterprises scale without the complexity of traditional hiring.',
      mission: 'Our Mission',
      missionText: 'To provide the operational backbone for high-growth companies, enabling them to focus on innovation while we handle the precision execution of daily business operations.',
      vision: 'Our Vision',
      visionText: 'A world where business scaling is limited only by imagination, not by operational friction.',
      storyTitle: 'Our Journey',
      story1: 'Founded by industry veterans, Gabriel was born out of a realization: growth-stage companies often struggle with the weight of their own operational success.',
      story2: 'We built a system that blends human intelligence with digital efficiency, creating a seamless extension of your internal teams.',
      story3: 'Today, we support over 500 enterprises globally, managing their most critical administrative and technical lifelines.',
      valuesTitle: 'Our Core Values',
      values: [
        { title: 'Reliability', text: 'Consistency is our baseline. We deliver on time, every time.' },
        { title: 'Integrity', text: 'We act as a true partner, prioritizing your interests as our own.' },
        { title: 'Innovation', text: 'Always seeking better, faster, and smarter ways to work.' },
        { title: 'Precision', text: 'Details matter. We execute with surgical accuracy.' }
      ],
      ctaTitle: 'Ready to build your backbone?',
      ctaBtn: 'Let\'s Talk Strategy'
    },
    careers: {
      heroTitle: 'Join the Gabriel Team',
      heroSubtitle: 'Build the future of professional outsourcing with a global, elite team.',
      whyTitle: 'Why Work With Us?',
      perksTitle: 'Benefits & Perks',
      positionsTitle: 'Open Positions',
      apply: 'Apply Now',
      generalTitle: 'Don\'t see the right fit?',
      generalBtn: 'Send General Application'
    },
    learning: {
      heroTitle: 'Learning Hub',
      heroSubtitle: 'Expert-curated modules on operational excellence and enterprise growth.',
      readMore: 'Start Module',
      categories: ['All', 'Logistics', 'IT Support', 'Customer Experience', 'C-Level Support'],
      modules: [
        {
          title: 'Advanced Fleet Optimization',
          category: 'Logistics',
          icon: 'fas fa-truck-fast',
          excerpt: 'Strategies for maximizing asset utilization and reducing carbon footprint through advanced route mapping.',
          duration: '25 min'
        },
        {
          title: 'Cybersecurity for Remote SMBs',
          category: 'IT Support',
          icon: 'fas fa-shield-halved',
          excerpt: 'Essential protocols for securing distributed workforces and protecting proprietary enterprise data.',
          duration: '30 min'
        },
        {
          title: 'The Psychology of CX Design',
          category: 'Customer Experience',
          icon: 'fas fa-heart-pulse',
          excerpt: 'Understanding the emotional drivers behind customer loyalty and high net promoter scores.',
          duration: '20 min'
        },
        {
          title: 'Strategic Executive Support',
          category: 'C-Level Support',
          icon: 'fas fa-user-tie',
          excerpt: 'Frameworks for fractional executive assistance and high-impact administrative partnership.',
          duration: '15 min'
        },
        {
          title: 'Scalable Service Desk Frameworks',
          category: 'IT Support',
          icon: 'fas fa-laptop-code',
          excerpt: 'Building Level I & II support systems that grow seamlessly with your user base.',
          duration: '35 min'
        },
        {
          title: 'Omnichannel Customer Relations',
          category: 'Customer Experience',
          icon: 'fas fa-comments',
          excerpt: 'Mastering the art of consistent messaging across voice, chat, email, and social channels.',
          duration: '22 min'
        },
        {
          title: 'Supply Chain Resilience',
          category: 'Logistics',
          icon: 'fas fa-boxes-stacked',
          excerpt: 'Navigating global disruptions with agile inventory management and diverse sourcing strategies.',
          duration: '28 min'
        },
        {
          title: 'Crisis Management for Leadership',
          category: 'C-Level Support',
          icon: 'fas fa-briefcase',
          excerpt: 'Operational playbooks for maintaining clarity and continuity during unexpected business pivots.',
          duration: '40 min'
        }
      ]
    },
    blog: {
      heroTitle: 'Insights & Innovation',
      heroSubtitle: 'Leading the conversation on the future of fractional operations.',
      categories: ['All', 'Operations', 'Growth', 'Technology'],
      readMore: 'Read Article',
      posts: [
        {
          title: 'The Future of Fractional Ops',
          category: 'Operations',
          date: 'Feb 12, 2026',
          excerpt: 'How SMBs are leveraging fractional teams to compete with enterprises.'
        },
        {
          title: 'Logistics Mapping in 2026',
          category: 'Technology',
          date: 'Jan 28, 2026',
          excerpt: 'New AI-driven routing protocols are saving fleets thousands in fuel costs.'
        },
        {
          title: 'Scaling Customer Success',
          category: 'Growth',
          date: 'Jan 15, 2026',
          excerpt: 'The art of maintaining human-centric support during rapid user acquisition.'
        }
      ]
    },
    contact: {
      heroTitle: 'Connect With Our Experts',
      heroSubtitle: 'Ready to scale? We\'re here to help you architect your growth engine.',
      formTitle: 'Send a Message',
      infoTitle: 'Contact Information',
      fullName: 'Full Name',
      email: 'Work Email',
      company: 'Company Name',
      phone: 'Phone Number',
      interest: 'Service Interest',
      message: 'Message',
      submit: 'Send Inquiry'
    },
    services: {
      heroTitle: 'Solutions for Scale',
      heroSubtitle: 'Every service we provide is designed to remove a bottleneck in your growth cycle.',
      learnMore: 'Explore Service',
      enterprise: 'Scalable Infrastructure',
      techTitle: 'The Tech-Driven Edge',
      techSubtitle: 'We leverage modern platforms to give your SMB enterprise-level efficiency.',
      ctaTitle: 'Ready to remove your growth bottlenecks?',
      ctaBtn: 'Schedule Your Consultation',
      list: {
        logistics: {
          title: 'Logistics Management',
          desc: 'Optimize your supply chain with our end-to-end logistics solutions. We handle dispatching, tracking, and fleet management.'
        },
        itsupport: {
          title: 'IT Support Level I & II',
          desc: 'Keep your business running smoothly with 24/7 technical support. Our experts resolve issues quickly and minimize downtime.'
        },
        admin: {
          title: 'C-Level Admin Support',
          desc: 'Executive-level assistance designed for leadership. We manage calendars, communications, and strategic projects.'
        },
        relations: {
          title: 'Customer Relations',
          desc: 'Build lasting relationships with your clients. Our dedicated teams handle inquiries and outreach with professionalism.'
        }
      },
      pages: {
        logistics: {
          title: 'Logistics Management',
          subtitle: 'Streamline your supply chain with our comprehensive logistics solutions. Efficiency, reliability, and real-time visibility for your fleet.',
          cta: 'Ready to Optimize Your Logistics?',
          btn: 'Get Started Now',
          f1: 'Route Optimization',
          f1d: 'Reduce fuel costs and delivery times with advanced route planning.',
          f2: 'Fleet Management',
          f2d: 'Real-time tracking and maintenance scheduling for your entire fleet.',
          f3: 'Inventory Control',
          f3d: 'Precision tracking of goods from warehouse to final destination.',
          f4: 'Analytics Dashboard',
          f4d: 'Comprehensive reporting on performance metrics and KPIs.',
          f5: 'On-Time Delivery',
          f5d: 'Guarantee punctual deliveries with predictive ETA updates.',
          f6: 'Compliance Safety',
          f6d: 'Ensure all operations meet regulatory standards and safety protocols.'
        },
        itsupport: {
          title: 'IT Support Level I & II',
          subtitle: 'Reliable 24/7 technical support to keep your business running smoothly. From troubleshooting to advanced network security.',
          cta: 'Secure Your Infrastructure Today',
          btn: 'Contact IT Sales',
          f1: 'Help Desk Support',
          f1d: 'Immediate assistance for user issues, software glitches, and hardware failures.',
          f2: 'Cybersecurity',
          f2d: 'Robust protection against malware, phishing, and data breaches.',
          f3: 'Server Management',
          f3d: 'Proactive monitoring and maintenance of your server infrastructure.',
          f4: 'Network Solutions',
          f4d: 'Setup and optimization of secure, high-speed office networks.',
          f5: 'Software Updates',
          f5d: 'Regular patching and updates to ensure system stability and security.',
          f6: 'Access Control',
          f6d: 'Secure management of user permissions and identity verification.'
        },
        admin: {
          title: 'C-Level Admin Support',
          subtitle: 'Executive assistance designed for leadership. We handle the details so you can lead with clarity and focus.',
          cta: 'Empower Your Leadership',
          btn: 'Find Your Assistant',
          f1: 'Calendar Management',
          f1d: 'Complex scheduling across time zones to maximize your productivity.'
        },
        relations: {
          title: 'Customer Relations',
          subtitle: 'Build lasting loyalty with exceptional customer service. We handle every interaction with care, professionalism, and empathy.',
          cta: 'Delight Your Customers',
          btn: 'Get Started Now'
        }
      }
    }
  },
  ES: {
    nav: {
      home: 'Inicio',
      services: 'Servicios',
      about: 'Nosotros',
      careers: 'Carreras',
      contact: 'Contacto',
      signin: 'Portal de Clientes',
      getstarted: 'Empezar a Escalar',
      submenu: {
        logistics: 'Gestión Logística',
        itsupport: 'Soporte TI Nivel I y II',
        admin: 'Soporte Admin Nivel C',
        relations: 'Relaciones con Clientes'
      }
    },
    checkout: {
      title: 'Pago Seguro',
      subtitle: 'Finaliza tu suscripción de operaciones fraccionadas.',
      billingInfo: 'Información de Facturación',
      paymentMethod: 'Método de Pago',
      orderSummary: 'Resumen del Pedido',
      payNow: 'Completar Pago',
      secureNote: 'Su pago se procesa de forma segura a través de Stripe. Cumplimos con los estándares PCI DSS, NIST y OWASP.',
      success: '¡Pago Exitoso!',
      successDesc: 'Se está aprovisionando su equipo operativo. Recibirá un correo electrónico de bienvenida en breve.',
      service: 'Servicio',
      price: 'Precio',
      total: 'Total',
      placeholder: {
        card: 'Número de tarjeta',
        expiry: 'MM/AA',
        cvc: 'CVC',
        zip: 'Código Postal'
      },
      prices: {
        logistics: 3799.99,
        itsupport_l1: 3499.99,
        itsupport_l2: 4399.99,
        admin: 2599.99,
        relations: 2359.99
      },
      plans: {
        logistics: 'Gestión Logística',
        itsupport_l1: 'Soporte TI Nivel I',
        itsupport_l2: 'Soporte TI Nivel II',
        admin: 'Soporte Administrativo Nivel C',
        relations: 'Relaciones con Clientes'
      }
    },
    auth: {
      welcome: 'Escala más Rápido',
      welcomeDesc: 'Accede a tu panel operativo dedicado y gestiona tu velocidad de escalado en tiempo real.',
      signinTitle: 'Iniciar Sesión',
      signinSubtitle: 'Ingresa tus credenciales para acceder al portal Gabriel.',
      email: 'Correo de Trabajo',
      password: 'Contraseña',
      forgot: '¿Olvidaste tu contraseña?',
      noAccount: '¿No tienes una cuenta?',
      startTrial: 'Inicia una prueba.',
      trialTitle: 'Inicia tu Piloto de 14 Días',
      trialSubtitle: 'Experimenta el poder de las operaciones fraccionadas sin compromiso a largo plazo.',
      perks: ['Gestor de Cuenta Dedicado', 'Acceso a Soporte 24/7', 'Analítica en Tiempo Real', 'Flujos Personalizados'],
      rating: 'calificación de más de 500 empresas',
      getStartedTitle: 'Crea Tu Cuenta',
      step: 'Paso',
      firstName: 'Nombre',
      lastName: 'Apellido',
      workEmail: 'Correo de Trabajo',
      phone: 'Teléfono',
      companyName: 'Nombre de la Empresa',
      companySize: 'Tamaño de la Empresa',
      primaryInterest: 'Interés Principal',
      continue: 'Continuar',
      back: 'Atrás',
      createAccount: 'Crear Cuenta',
      alreadyHave: '¿Ya tienes una cuenta?'
    },
    legal: {
      privacyTitle: 'Política de Privacidad',
      termsTitle: 'Términos de Servicio',
      gdprTitle: 'Cumplimiento RGPD',
      consentTitle: 'Preferencias de Consentimiento',
      lastUpdated: 'Última actualización: Febrero 2026',
      required: 'Requerido',
      save: 'Guardar Preferencias',
      acceptAll: 'Aceptar Todo'
    },
    footer: {
      description: 'Servicios profesionales que incluyen logística, soporte de TI, asistencia de nivel C y relaciones con los clientes. Optimizando operaciones para empresas modernas.',
      services: 'Servicios',
      company: 'Empresa',
      contact: 'Contacto',
      privacy: 'Política de Privacidad',
      terms: 'Términos de Servicio',
      gdpr: 'RGPD',
      consent: 'Preferencias de Consentimiento',
      rights: 'Todos los derechos reservados.',
      tagline: 'Construido para la excelencia.',
      links: {
        logistics: 'Gestión Logística',
        itsupport: 'Soporte TI',
        admin: 'Admin Nivel C',
        relations: 'Relaciones con Clientes',
        about: 'Sobre Nosotros',
        careers: 'Carreras',
        learning: 'Centro de Aprendizaje',
        contact: 'Contacto'
      }
    },
    home: {
      badge: 'Expertos en Crecimiento y Escalabilidad para Pymes',
      title: 'Escala tu Negocio,',
      titleSuffix: 'No tu Carga de Trabajo',
      subtitle: 'Recupera tu tiempo y acelera el crecimiento. Brindamos soporte operativo de alto rendimiento para que puedas enfocarte en lo importante. Outsourcing de precisión para la Pyme moderna.',
      explore: 'Ver Soluciones',
      demo: 'Obtener Auditoría de Crecimiento',
      insightTitle: 'Claves de Escalabilidad para Pymes',
      insight1: {
        title: 'Delegación 80/20',
        text: 'Libérate del 80% de las tareas repetitivas para enfocarte en el 20% de trabajo estratégico.'
      },
      insight2: {
        title: 'Operaciones Fraccionadas',
        text: 'Accede a experiencia operativa de nivel C sin el costo de un salario de tiempo completo.'
      },
      insight3: {
        title: 'Escalabilidad Global',
        text: 'Implementa flujos de trabajo 24/7 que mantengan tu negocio funcionando mientras duermes.'
      },
      ctaTitle: 'Tu próxima fase de crecimiento comienza con una conversación.',
      ctaSubtitle: 'No permitas que la fricción operativa frene tu visión. Construyamos tu estructura.'
    },
    about: {
      heroTitle: 'Excelencia en la Ejecución',
      heroSubtitle: 'Ayudando a empresas modernas a escalar sin la complejidad de la contratación tradicional.',
      mission: 'Nuestra Misión',
      missionText: 'Proporcionar la estructura operativa para empresas de alto crecimiento, permitiéndoles centrarse en la innovación mientras nosotros nos encargamos de la ejecución precisa de las operaciones diarias.',
      vision: 'Nuestra Visión',
      visionText: 'Un mundo donde el escalamiento empresarial solo esté limitado por la imaginación, no por la fricción operativa.',
      storyTitle: 'Nuestro Viaje',
      story1: 'Fundada por veteranos de la industria, Gabriel nació de una comprensión: las empresas en etapa de crecimiento a menudo luchan con el peso de su propio éxito operativo.',
      story2: 'Construimos un sistema que combina la inteligencia humana con la eficiencia digital, creando una extensión fluida de sus equipos internos.',
      story3: 'Hoy, apoyamos a más de 500 empresas a nivel mundial, gestionando sus líneas de vida administrativas y técnicas más críticas.',
      valuesTitle: 'Nuestros Valores',
      values: [
        { title: 'Confiabilidad', text: 'La consistencia es nuestra base. Cumplimos a tiempo, siempre.' },
        { title: 'Integridad', text: 'Actuamos como un verdadero socio, priorizando sus intereses como los nuestros.' },
        { title: 'Innovación', text: 'Buscando siempre mejores, más rápidas y más inteligentes formas de trabajar.' },
        { title: 'Precisión', text: 'Los detalles importan. Ejecutamos con precisión quirúrgica.' }
      ],
      ctaTitle: '¿Listo para construir su estructura?',
      ctaBtn: 'Hablemos de Estrategia'
    },
    careers: {
      heroTitle: 'Únete al Equipo Gabriel',
      heroSubtitle: 'Construye el futuro del outsourcing profesional con un equipo de élite global.',
      whyTitle: '¿Por qué trabajar con nosotros?',
      perksTitle: 'Beneficios y Ventajas',
      positionsTitle: 'Posiciones Abiertas',
      apply: 'Postular Ahora',
      generalTitle: '¿No ves el ajuste adecuado?',
      generalBtn: 'Enviar Postulación General'
    },
    learning: {
      heroTitle: 'Centro de Aprendizaje',
      heroSubtitle: 'Módulos curados por expertos sobre excelencia operativa y crecimiento empresarial.',
      readMore: 'Iniciar Módulo',
      categories: ['Todos', 'Logística', 'Soporte TI', 'Experiencia del Cliente', 'Soporte Nivel C'],
      modules: [
        {
          title: 'Optimización Avanzada de Flotas',
          category: 'Logística',
          icon: 'fas fa-truck-fast',
          excerpt: 'Estrategias para maximizar la utilización de activos y reducir la huella de carbono mediante mapeo de rutas optimizado.',
          duration: '25 min'
        },
        {
          title: 'Ciberseguridad para Pymes Remotas',
          category: 'Soporte TI',
          icon: 'fas fa-shield-halved',
          excerpt: 'Protocolos esenciales para asegurar fuerzas de trabajo distribuidas y proteger datos empresariales.',
          duration: '30 min'
        },
        {
          title: 'Psicología del Diseño CX',
          category: 'Experiencia del Cliente',
          icon: 'fas fa-heart-pulse',
          excerpt: 'Entendiendo los impulsores emocionales detrás de la lealtad del cliente y los altos puntajes de NPS.',
          duration: '20 min'
        },
        {
          title: 'Soporte Ejecutivo Estratégico',
          category: 'Soporte Nivel C',
          icon: 'fas fa-user-tie',
          excerpt: 'Marcos para la asistencia ejecutiva fraccionada y asociaciones administrativas de alto impacto.',
          duration: '15 min'
        },
        {
          title: 'Sistemas de Mesa de Ayuda Escalables',
          category: 'Soporte TI',
          icon: 'fas fa-laptop-code',
          excerpt: 'Construyendo sistemas de soporte Nivel I y II que crecen sin problemas con su base de usuarios.',
          duration: '35 min'
        },
        {
          title: 'Relaciones Omnicanal con Clientes',
          category: 'Experiencia del Cliente',
          icon: 'fas fa-comments',
          excerpt: 'Dominando el arte del mensaje consistente a través de voz, chat, correo y canales sociales.',
          duration: '22 min'
        },
        {
          title: 'Resiliencia de la Cadena de Suministro',
          category: 'Logística',
          icon: 'fas fa-boxes-stacked',
          excerpt: 'Navigando interrupciones globales con gestión ágil de inventarios y estrategias de abastecimiento diversas.',
          duration: '28 min'
        },
        {
          title: 'Gestión de Crisis para Liderazgo',
          category: 'Soporte Nivel C',
          icon: 'fas fa-briefcase',
          excerpt: 'Libros de jugadas operativas para mantener la claridad y continuidad durante giros comerciales inesperados.',
          duration: '40 min'
        }
      ]
    },
    blog: {
      heroTitle: 'Perspectivas e Innovación',
      heroSubtitle: 'Liderando la conversación sobre el futuro de las operaciones fraccionadas.',
      categories: ['Todos', 'Operaciones', 'Crecimiento', 'Tecnología'],
      readMore: 'Leer Artículo',
      posts: [
        {
          title: 'El Futuro de las Operaciones Fraccionadas',
          category: 'Operaciones',
          date: '12 Feb, 2026',
          excerpt: 'Cómo las Pymes están aprovechando equipos fraccionados para competir con grandes empresas.'
        },
        {
          title: 'Mapeo Logístico en 2026',
          category: 'Tecnología',
          date: '28 Ene, 2026',
          excerpt: 'Nuevos protocolos de enrutamiento impulsados por IA están ahorrando miles en combustible.'
        },
        {
          title: 'Escalando el Éxito del Cliente',
          category: 'Crecimiento',
          date: '15 Ene, 2026',
          excerpt: 'El arte de mantener un soporte centrado en el humano durante la adquisición rápida de usuarios.'
        }
      ]
    },
    contact: {
      heroTitle: 'Conéctate con Nuestros Expertos',
      heroSubtitle: '¿Listo para escalar? Estamos aquí para ayudarte a diseñar tu motor de crecimiento.',
      formTitle: 'Enviar un Mensaje',
      infoTitle: 'Información de Contacto',
      fullName: 'Nombre Completo',
      email: 'Correo de Trabajo',
      company: 'Nombre de la Empresa',
      phone: 'Número de Teléfono',
      interest: 'Interés en el Servicio',
      message: 'Mensaje',
      submit: 'Enviar Consulta'
    },
    services: {
      heroTitle: 'Soluciones para Escalar',
      heroSubtitle: 'Cada servicio que brindamos está diseñado para eliminar un cuello de botella en su ciclo de crecimiento.',
      learnMore: 'Explorar Servicio',
      enterprise: 'Infraestructura Escalable',
      techTitle: 'Ventaja Impulsada por Tecnología',
      techSubtitle: 'Aprovechamos plataformas modernas para darle a tu Pyme una eficiencia de nivel empresarial.',
      ctaTitle: '¿Listo para eliminar tus cuellos de botella?',
      ctaBtn: 'Programa tu Consulta',
      list: {
        logistics: {
          title: 'Gestión Logística',
          desc: 'Optimice su cadena de suministro con nuestras soluciones logísticas integrales. Manejamos despacho, seguimiento y gestión de flotas.'
        },
        itsupport: {
          title: 'Soporte TI Nivel I y II',
          desc: 'Mantenga su negocio funcionando sin problemas con soporte técnico 24/7. Nuestros expertos resuelven problemas rápidamente.'
        },
        admin: {
          title: 'Soporte Admin Nivel C',
          desc: 'Asistencia de nivel ejecutivo diseñada para el liderazgo. Gestionamos calendarios, comunicaciones y proyectos estratégicos.'
        },
        relations: {
          title: 'Relaciones con Clientes',
          desc: 'Construya relaciones duraderas con sus clientes. Nuestros equipos dedicados manejan consultas con profesionalismo.'
        }
      },
      pages: {
        logistics: {
          title: 'Gestión de Logística',
          subtitle: 'Optimice su cadena de suministro con nuestras soluciones logísticas integrales. Eficiencia, confiabilidad y visibilidad en tiempo real para su flota.',
          cta: '¿Listo para optimizar su logística?',
          btn: 'Empezar Ahora',
          f1: 'Optimización de Rutas',
          f1d: 'Reduzca los costos de combustible y los tiempos de entrega con planificación de rutas avanzada.',
          f2: 'Gestión de Flotas',
          f2d: 'Seguimiento en tiempo real y programación de mantenimiento para toda su flota.',
          f3: 'Control de Inventario',
          f3d: 'Seguimiento de precisión de mercancías desde el almacén hasta el destino final.',
          f4: 'Tablero de Análisis',
          f4d: 'Informes completos sobre métricas de rendimiento y KPI.',
          f5: 'Entrega a Tiempo',
          f5d: 'Garantice entregas puntuales con actualizaciones predictivas de ETA.',
          f6: 'Seguridad y Cumplimiento',
          f6d: 'Asegúrese de que todas las operaciones cumplan con los estándares regulatorios y los protocolos de seguridad.'
        },
        itsupport: {
          title: 'Soporte de TI Nivel I y II',
          subtitle: 'Soporte técnico confiable las 24 horas para que su negocio funcione sin problemas. Desde resolución de problemas hasta seguridad avanzada.',
          cta: 'Asegure su infraestructura hoy',
          btn: 'Contactar Ventas TI',
          f1: 'Soporte de Mesa de Ayuda',
          f1d: 'Asistencia inmediata para problemas de usuario, fallas de software y hardware.',
          f2: 'Ciberseguridad',
          f2d: 'Protección robusta contra malware, phishing y filtraciones de datos.',
          f3: 'Gestión de Servidores',
          f3d: 'Monitoreo proactivo y mantenimiento de su infraestructura de servidores.',
          f4: 'Soluciones de Red',
          f4d: 'Configuración y optimización de redes de oficina seguras y veloces.',
          f5: 'Actualizaciones de Software',
          f5d: 'Parches y actualizaciones regulares para garantizar estabilidad y seguridad.',
          f6: 'Control de Acceso',
          f6d: 'Gestión segura de permisos de usuario y verificación de identidad.'
        },
        admin: {
          title: 'Soporte Administrativo Nivel C',
          subtitle: 'Asistencia ejecutiva diseñada para el liderazgo. Manejamos los detalles para que usted pueda liderar con claridad y enfoque.',
          cta: 'Potencie su Liderazgo',
          btn: 'Encuentre su Asistente',
          f1: 'Gestión de Calendario',
          f1d: 'Programación compleja en zonas horarias para maximizar su productividad.'
        },
        relations: {
          title: 'Relaciones con Clientes',
          subtitle: 'Construya lealtad duradera con un servicio al cliente excepcional. Manejamos cada interacción con cuidado, profesionalismo y empatía.',
          cta: 'Deleite a sus Clientes',
          btn: 'Empezar Ahora'
        }
      }
    }
  }
};