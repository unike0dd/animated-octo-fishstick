
import React from 'react';

export type Page = 'home' | 'services' | 'about' | 'careers' | 'contact' | 'signin' | 'getstarted' | 'privacy' | 'terms' | 'gdpr' | 'consent' | 'logistics' | 'itsupport' | 'admin' | 'relations' | 'learning' | 'checkout' | 'mobile-preview' | 'dart-dashboard';

export type Language = 'EN' | 'ES';

export interface NavItem {
  label: string;
  value: Page;
  subItems?: { label: string; href: string }[];
}

export interface Testimonial {
  quote: string;
  author: string;
  role: string;
  company: string;
  stars: number;
}

export interface Service {
  title: string;
  description: string;
  icon: React.ElementType;
}

export interface JobPosition {
  title: string;
  department: string;
  type: string;
  location: string;
}
